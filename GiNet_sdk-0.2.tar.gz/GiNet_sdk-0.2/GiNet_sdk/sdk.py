import requests
from loguru import logger
from datetime import datetime, timedelta
import base64 
import json
from typing import Dict, Any, List, Optional
from langgraph.checkpoint.postgres import PostgresSaver
from psycopg_pool import ConnectionPool
from psycopg.rows import dict_row

class GiNetSDK:
    """
    SDK for interacting with GiNet Platform APIs.
    """

    def __init__(self, base_url: str, giNet_username: str, giNet_password: str, agenticWorkflow: bool=False):
        self.base_url = base_url
        self.giNet_username = giNet_username
        self.giNet_password = giNet_password
        self.token: Optional[str] = None
        self.expiry_time: Optional[datetime] = None
        self.created_time: Optional[datetime] = None

        # Postgres memory DB initialization
        if agenticWorkflow:
            self.postgres = self.get_memory_db_details()["postgresDb"]
            connection_kwargs ={
                "autocommit": True,
                "prepare_threshold": 0,
                "row_factory": dict_row,
            }
            self.memory = ConnectionPool(
                # Example configuration
                conninfo=self.postgres,
                max_size=200,
                kwargs=connection_kwargs
            )
            with self.memory.connection() as conn:
                checkpointer = PostgresSaver(conn)
                checkpointer.setup()


    def get_auth_token(self) -> str:
        logger.debug("inside getAuthToken")
        authentication_url = self.base_url + "/login"
        time_now = datetime.now()  # Now offset-naive
        logger.debug(f"current timeNow: {time_now}")
        logger.debug(f"current expiryTime: {self.expiry_time}")
        try:
            if self.expiry_time is None or self.expiry_time < time_now:
                logger.debug("inside token generation block for generating new token")
                # Encode username and password using Base64
                logger.debug(f"username: {self.giNet_username} , password:{self.giNet_password}")
                credentials = f"{self.giNet_username}:{self.giNet_password}"
                encoded_credentials = base64.b64encode(credentials.encode('ascii')).decode('ascii')
                headers = {
                    'Content-Type': 'application/json',
                    'Authorization': f'Basic {encoded_credentials}'
                }

                payload = json.dumps({
                    "username": self.giNet_username,
                    "password": self.giNet_password
                })
                headers = {
                    'Content-Type': 'application/json'
                }
                logger.debug(f"authentication_url: {authentication_url}")

                response = requests.request("POST", authentication_url, headers=headers, verify=False, data=payload)

                logger.debug(f"response for getAuth: {response}, {type(response)}")
                # response.raise_for_status()  # Raise an exception for bad status codes
                if response.status_code == 200:
                    try:
                        response_json = response.json()  # Convert to JSON
                        print(response_json)  # Access data as a Python dictionary
                    except requests.exceptions.JSONDecodeError:
                        print("Invalid JSON response received.")

                logger.info("response: {}", response_json)
                self.created_time = datetime.now()  # Offset-naive
                expires_at_datetime = datetime.fromisoformat(response_json["expiry_time"]) 
                # Make expires_at_datetime offset-naive 
                expires_at_datetime = expires_at_datetime.replace(tzinfo=None)

                # Calculate the tokenTimeout in seconds
                token_timeout = (expires_at_datetime - self.created_time).total_seconds()  # Now you can compare
                logger.debug(f"tokenTimeout: {token_timeout}")

                self.expiry_time = self.created_time + timedelta(seconds=token_timeout)
                logger.debug(f"expiryTime after adding timeout: {self.expiry_time}")
                logger.debug(f"createdTime:{self.created_time}")
                logger.debug(f"expiryTIme:{self.expiry_time}")
                self.token = response_json["token"]
        except Exception as e:
            logger.error(
                f"Error occurred while making getAuthToken API call on URL: {authentication_url} , Exception details: {e}"
            )
        logger.debug(f"authentication token: {self.token}")
        return self.token    

    def rag_intelligence(self, query: str, prompt_template: str, conversation_id: int = 0, workflow_name: str = "WorkflowAgent") -> Dict[str, Any]:
        """
        Sends a query to the RAG Intelligence API.

        Args:
            query: The user query.
            prompt_template: The prompt template to use.
            conversation_id: The ID of the conversation (optional).
            workflow_name: name of AI Agentic workflow

        Returns:
            A dictionary containing the response from the API.
        """
        url = f"{self.base_url}/sdk/ragIntelligence"
        data = {"query": query, "prompt_template": prompt_template, "conversation_id": conversation_id, "workflow_name": workflow_name}
        response = requests.post(url, json=data, headers={'Content-Type': 'application/json', 'Authorization': f'Bearer {self.get_auth_token()}'})
        response.raise_for_status()
        return response.json()

    def pre_trained_intelligence(self, query: str, prompt_template: str, conversation_id: int = 0, workflow_name: str = "WorkflowAgent") -> Dict[str, Any]:
        """
        Sends a query to the Pre-Trained Intelligence API.

        Args:
            query: The user query.
            prompt_template: The prompt template to use.
            conversation_id: The ID of the conversation (optional).
            workflow_name: name of AI Agentic workflow

        Returns:
            A dictionary containing the response from the API.
        """
        url = f"{self.base_url}/sdk/preTrainedIntelligence"
        data = {"query": query, "prompt_template": prompt_template, "conversation_id": conversation_id, "workflow_name": workflow_name}
        response = requests.post(url, json=data, headers={'Content-Type': 'application/json', 'Authorization': f'Bearer {self.get_auth_token()}'})
        response.raise_for_status()
        return response.json()
    
    def get_llm_details(self) -> Dict[str, Any]:
        """
        Sends a query to get llm API and model name details.

        Args: None

        Returns:
            A dictionary containing the response from the API with LLM Key.
        """
        url = f"{self.base_url}/sdk/getLlmDetails"
        response = requests.get(url, headers={'Content-Type': 'application/json', 'Authorization': f'Bearer {self.get_auth_token()}'})
        response.raise_for_status()
        return response.json()
    
    def get_memory_db_details(self) -> Dict[str, Any]:
        """
        Sends a query to get agentic workflow memory DB details.

        Args: None

        Returns:
            A dictionary containing the response from the API with memory DB details.
        """
        url = f"{self.base_url}/sdk/getMemoryDbDetails"
        response = requests.get(url, headers={'Content-Type': 'application/json', 'Authorization': f'Bearer {self.get_auth_token()}'})
        response.raise_for_status()
        return response.json()
    
    def get_conversation_history(self, query: str, conversation_id: int = 0) -> Dict[str, Any]:
        """
        Sends a query and conversation_id to the get_conversation_history API to get the conversation history.

        Args:
            query: The user query.
            conversation_id: The ID of the conversation (optional).

        Returns:
            A dictionary containing the response from the API.
        """
        url = f"{self.base_url}/sdk/getConvHistory"
        data = {"query": query, "conversation_id": conversation_id}
        response = requests.get(url, json=data, headers={'Content-Type': 'application/json', 'Authorization': f'Bearer {self.get_auth_token()}'})
        response.raise_for_status()
        return response.json()

    def register_chat_workflow(self, workflow_name: str, base_url: str, workflow_type: str, description: str, document_name: str = None, forum_name: str = None) -> Dict[str, Any]:
        """
        Registers a new chat workflow.

        Args:
            workflow_name: The name of the workflow.
            base_url: The base URL of the workflow.
            workflow_type: The type of the workflow. Mention 'chat' for chat capable workflow
            description: brief description of this AI agentic workflow
            document_name: name of document to be used as context. Make this None when doc based context is not required.
            forum_name: name of forum with the group of documentsto be used as context. Make this None when forum based context is not required.

        Returns:
            A dictionary containing the response from the API.
        """
        if forum_name is not None and document_name is not None:
            raise ValueError("Both document_name and forum_name cannot be provided. Please provide only one of them.")
        
        url = f"{self.base_url}/sdk/registerChatWorkflow"
        data = {"workflow_name": workflow_name, "base_url": base_url, "workflow_type": workflow_type, "description": description, "document_name": document_name, "forum_name": forum_name}
        response = requests.post(url, json=data, headers={'Content-Type': 'application/json', 'Authorization': f'Bearer {self.get_auth_token()}'})
        response.raise_for_status()
        return response.json()

    def make_api_call(self, application_name: str, api_url: str, method: str, params: Optional[Dict] = None, 
                      request_body: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Makes an API call to the specified endpoint through the GiNet platform.

        Args:
            application_name: Name of the application making the API call
            api_url: The URL of the API to call
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            params: Optional query parameters
            request_body: Optional request body data

        Returns:
            A dictionary containing the response from the API.
        """
        url = f"{self.base_url}/sdk/makeApiCall"
        data = {
            "application_name": application_name,
            "api_url": api_url,
            "method": method,
            "params": params,
            "request_body": request_body
        }
        
        response = requests.post(
            url, 
            json=data, 
            headers={'Content-Type': 'application/json', 'Authorization': f'Bearer {self.get_auth_token()}'}
        )
        response.raise_for_status()
        return response.json()
