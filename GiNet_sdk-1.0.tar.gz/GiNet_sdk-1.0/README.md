# Gi-Net SDK

This SDK provides a convenient way to interact with the RAG Intelligence API, enabling you to easily leverage powerful RAG and pre-trained model capabilities within your applications.

# Package SDK
```
python setup.py sdist bdist_wheel
```

This will create a dist directory containing two files:
`GiNet_sdk-0.1.0.tar.gz`: The source distribution.
`GiNet_sdk-0.1.0-py3-none-any.whl`: A wheel distribution (generally preferred for installation).

## Install from the .tar.gz File:
You can now install your SDK using the generated .tar.gz file locally:
`pip install GiNet_sdk-0.1.0.tar.gz`

### Sample output on install:
```
PS C:\NetoAI\GiNet\planning-CoPilot> pip install ..\sdk\dist\GiNet_sdk-0.1.0.tar.gz
Processing c:\netoai\ginet\sdk\dist\ginet_sdk-0.1.0.tar.gz
  Preparing metadata (setup.py) ... done
Requirement already satisfied: requests in c:\users\vigne\appdata\local\programs\python\python310\lib\site-packages (from GiNet-sdk==0.1.0) (2.32.3)
Requirement already satisfied: charset-normalizer<4,>=2 in c:\users\vigne\appdata\local\programs\python\python310\lib\site-packages (from requests->GiNet-sdk==0.1.0) (3.3.2)
Requirement already satisfied: idna<4,>=2.5 in c:\users\vigne\appdata\local\programs\python\python310\lib\site-packages (from requests->GiNet-sdk==0.1.0) (3.6)       
Requirement already satisfied: urllib3<3,>=1.21.1 in c:\users\vigne\appdata\local\programs\python\python310\lib\site-packages (from requests->GiNet-sdk==0.1.0) (2.2.1)
Requirement already satisfied: certifi>=2017.4.17 in c:\users\vigne\appdata\local\programs\python\python310\lib\site-packages (from requests->GiNet-sdk==0.1.0) (2024.2.2)
Building wheels for collected packages: GiNet-sdk
  Building wheel for GiNet-sdk (setup.py) ... done
  Created wheel for GiNet-sdk: filename=GiNet_sdk-0.1.0-py3-none-any.whl size=1081 sha256=6a92467fae6f8d1ddac9f38921d41e3202c28f24daaf06fb44218380fee934cb
  Stored in directory: c:\users\vigne\appdata\local\pip\cache\wheels\f2\49\67\58734e4478ef7557d530200cf60076df08305b4fb645ad506b
Successfully built GiNet-sdk
Installing collected packages: GiNet-sdk
Successfully installed GiNet-sdk-0.1.0
```

## Installation

```
pip install GiNet_sdk
```

## Methods

`rag_intelligence(query: str, conversation_id: int = 0) -> Dict[str, Any]`
Sends a query to the RAG Intelligence API.
Arguments:
query: The user query.
conversation_id: The ID of the conversation (optional).
Returns: A dictionary containing the response from the API.

`pre_trained_intelligence(query: str, prompt_template: str, conversation_id: int = 0) -> Dict[str, Any]`
Sends a query to the Pre-Trained Intelligence API.
Arguments:
query: The user query.
prompt_template: The prompt template to use.
conversation_id: The ID of the conversation (optional).
Returns: A dictionary containing the response from the API.

`register_chat_workflow(workflow_name: str, base_url: str, workflow_type: str) -> Dict[str, Any]`
Registers a new chat workflow.
Arguments:
workflow_name: The name of the workflow.
base_url: The base URL of the workflow.
workflow_type: The type of the workflow.
Returns: A dictionary containing the response from the API.

## Requirements
Python 3.6+
requests library


# Sample Usage
```
from loguru import logger
from flask import Flask, request, jsonify, make_response
from flask_cors import CORS
from GiNet_sdk.sdk import GiNetSDK

# API library Initialization
app = Flask(__name__)
CORS(app)

# Create object to access GiNet platform
gi = GiNetSDK("http://127.0.0.1:2005", "admin", "admin")


# Sample implementation showing usage of rag based chat, get conversation_id and pass it for memory
response = gi.rag_intelligence("What is it's full form?")
logger.debug(f"rag_intelligence Response: {response}")


# Sample implementation showing usage of TSLAM intelligence based chat, get conversation_id and pass it for memory
prompt = """
Answer with what you know on the given query. Provide responses in English.

previous_conversations: {previous_conversations}

Query: {query} 
"""
response = gi.pre_trained_intelligence("what is it's full form", prompt)
logger.debug(f"pre_trained_intelligence Response: {response}")


# Sample implementation to register the workflow as chat capable, to enable chat interface on GiNet to integrate with this
response = gi.register_chat_workflow("planning-copilot","http://127.0.0.1:2007/planning/getUserChat", "chat")

# Sample API implementation showcasing how the conversation from GiNet platform chat interface can be accessed on the workflow
@app.route('/planning/getUserChat', methods=['POST'])
def get_user_chat():
    data = request.json
    user_input = data.get('user_query')
    application_name= data.get('workflow_name')
    conversation_id = data.get('conversation_id')
    logger.debug(f"user_input: {user_input}, conversation_id: {conversation_id}, application_name: {application_name}")
    response = gi.pre_trained_intelligence(user_input, prompt, conversation_id)
    logger.debug(f"Response for user query: {response}")
    return response

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=2007)
```

**Remember to:**

- Replace placeholders like `username`, `password`, `'http://127.0.0.1:2005'` and `'http://127.0.0.1:2007/planning/getUserChat'` with your actual values.
