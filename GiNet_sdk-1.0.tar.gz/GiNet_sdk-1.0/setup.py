from setuptools import setup, find_packages
import setuptools.command.sdist

setuptools.command.sdist.sdist.user_options.append(
    ('include-package-data=', None, 'include package data')
)

setup(
    name='GiNet_sdk',
    version='1.0',
    description='SDK for interacting with Ving Platform',
    author='Vignesh Ethiraj',
    author_email='vignesh.e@netoai.ai',
    packages=find_packages(),
    install_requires=open('requirements.txt').read().splitlines(),
)